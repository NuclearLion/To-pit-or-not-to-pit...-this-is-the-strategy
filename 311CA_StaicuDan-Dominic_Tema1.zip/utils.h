//Copyright Dan-Dominic Staicu 311CA (dando.ds11@gmail.com) 2023
#ifndef _UTILS_H_
#define _UTILS_H_

#include <string.h>

int hash(char *command);

#endif
