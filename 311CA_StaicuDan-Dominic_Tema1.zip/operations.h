//Copyright Dan-Dominic Staicu 311CA (dando.ds11@gmail.com) 2023
#ifndef _OPERATIONS_H_
#define _OPERATIONS_H_

#include "structs.h"
#include <stdio.h>

void get_operations(void **operations);

#endif
