Copyright Dan-Dominic Staicu 311CA (dando.ds11@gmail.com) 2023
**Nume: Dan-Dominic Staicu**
**Grupă: 311CAb**

## To pit or not to pit... this is the strategy - Homework 1

### Description: