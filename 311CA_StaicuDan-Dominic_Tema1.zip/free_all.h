//Copyright Dan-Dominic Staicu 311CA (dando.ds11@gmail.com) 2023
#ifndef _FREE_ALL_H_
#define _FREE_ALL_H_

#include <stdlib.h>

#include "structs.h"

void free_all(sensor **a_sensors, int dim);

#endif
